package com.penjualan.pasar.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.penjualan.pasar.entity.Tampungan;


public interface TampunganRepository extends JpaRepository<Tampungan,Integer>{
    
}