package com.penjualan.pasar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PasarApplicationTests {

	@Test
	void contextLoads() {
	}

}
