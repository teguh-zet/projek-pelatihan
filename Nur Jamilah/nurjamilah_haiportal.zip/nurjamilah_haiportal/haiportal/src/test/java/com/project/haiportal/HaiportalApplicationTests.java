package com.project.haiportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HaiportalApplicationTests {

	@Test
	void contextLoads() {
	}

}
