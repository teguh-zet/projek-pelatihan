package com.project.haiportal.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.haiportal.models.Matkul;

public interface MatkulRepository extends JpaRepository<Matkul, Integer>{
    
}
