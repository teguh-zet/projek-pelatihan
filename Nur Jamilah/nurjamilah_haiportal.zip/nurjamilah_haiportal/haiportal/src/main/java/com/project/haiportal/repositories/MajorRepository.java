package com.project.haiportal.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.haiportal.models.Major;

public interface MajorRepository extends JpaRepository<Major, Integer>{
    
}
