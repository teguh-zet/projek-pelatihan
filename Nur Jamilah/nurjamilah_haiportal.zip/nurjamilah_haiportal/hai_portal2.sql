CREATE OR REPLACE DATABASE hai_portal2;
USE hai_portal2;

DROP DATABASE hai_portal2;