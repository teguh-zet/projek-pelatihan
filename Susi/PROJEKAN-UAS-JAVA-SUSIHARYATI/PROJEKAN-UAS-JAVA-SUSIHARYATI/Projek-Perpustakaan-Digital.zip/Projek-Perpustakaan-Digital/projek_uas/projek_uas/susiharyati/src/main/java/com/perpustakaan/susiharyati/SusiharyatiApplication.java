package com.perpustakaan.susiharyati;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SusiharyatiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SusiharyatiApplication.class, args);
	}

}
