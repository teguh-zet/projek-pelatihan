package com.perpustakaan.susiharyati.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.perpustakaan.susiharyati.models.Admin;

public interface AdminRepository extends JpaRepository<Admin,Integer>{


    
}
