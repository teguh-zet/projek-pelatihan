package com.perpustakaan.susiharyati.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.perpustakaan.susiharyati.models.Back;

public interface BackRepository extends JpaRepository<Back, Integer>{
    
}
