CREATE DATABASE perpustakaan_digital;
USE perpustakaan_digital;

INSERT INTO admin (full_name, PASSWORD, username)
 VALUES ('Susi Haryati','1304','admin');
 
DROP DATABASE perpustakaan_digital;