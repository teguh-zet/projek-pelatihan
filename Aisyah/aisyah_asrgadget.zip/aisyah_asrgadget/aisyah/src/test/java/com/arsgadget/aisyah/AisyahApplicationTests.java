package com.arsgadget.aisyah;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AisyahApplicationTests {

	@Test
	void contextLoads() {
	}

}
