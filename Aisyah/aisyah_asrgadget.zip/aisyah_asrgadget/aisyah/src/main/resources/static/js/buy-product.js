document
  .getElementById("id-customer")
  .setAttribute("value", localStorage.getItem("id"));
document
  .getElementById("name-customer")
  .setAttribute("value", localStorage.getItem("name"));
