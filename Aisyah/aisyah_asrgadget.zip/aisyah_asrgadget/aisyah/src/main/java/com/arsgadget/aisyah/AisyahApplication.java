package com.arsgadget.aisyah;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AisyahApplication {

	public static void main(String[] args) {
		SpringApplication.run(AisyahApplication.class, args);
	}
	
}