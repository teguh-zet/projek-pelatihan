package com.teazautogarage.teazauto.Repositories;
import org.springframework.data.jpa.repository.JpaRepository;

import com.teazautogarage.teazauto.Model.AdminLogin;
public interface AdminLoginRepository extends JpaRepository<AdminLogin,Long>{
    
}
