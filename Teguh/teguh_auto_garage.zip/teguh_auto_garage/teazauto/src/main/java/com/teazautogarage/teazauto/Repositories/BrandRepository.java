package com.teazautogarage.teazauto.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.teazautogarage.teazauto.Model.Brand;

public interface BrandRepository extends JpaRepository<Brand,Long>{
    
}
