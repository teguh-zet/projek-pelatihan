package com.teazautogarage.teazauto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeazautoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeazautoApplication.class, args);
	}

}
