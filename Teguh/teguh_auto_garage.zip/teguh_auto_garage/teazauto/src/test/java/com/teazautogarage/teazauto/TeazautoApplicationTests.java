package com.teazautogarage.teazauto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeazautoApplicationTests {

	@Test
	void contextLoads() {
	}

}
