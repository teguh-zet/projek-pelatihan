package com.projecthotel.anisaalawiyah;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnisaalawiyahApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnisaalawiyahApplication.class, args);
	}

}
